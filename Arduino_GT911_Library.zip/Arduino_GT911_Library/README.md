# Arduino GT911 Library
Arduino GT911 touch screen driver

Prototype of arduino-based library for GT911 touchscreen driver chip (tested on LilyGo LilyPi, 320x480 resolution).
Theoratically works on ESP8266/ESP32 and other platforms as well, however only tested on ESP32 yet.

Thanks to Aruino/linux/android Goodix drivers developers for references
* https://github.com/goodix/gt1x_driver_generic
* https://github.com/hadess/gt9xx (Also You can found specs in this repo)
* https://github.com/nik-sharky/arduino-goodix
* https://github.com/lewisxhe/FocalTech_Library/
